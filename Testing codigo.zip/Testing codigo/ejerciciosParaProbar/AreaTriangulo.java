/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejerciciosParaProbar;

/**
 *
 * @author Milton
 */
public class AreaTriangulo {
    public int area(int base, int altura){
        return (base * altura)/2;
    }
}
