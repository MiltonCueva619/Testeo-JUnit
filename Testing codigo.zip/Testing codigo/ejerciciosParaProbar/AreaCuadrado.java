/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejerciciosParaProbar;

/**
 *
 * @author User
 */
public class AreaCuadrado {
    public int area(int lado1, int lado2){
        return lado1 * lado2;
    }  
}
