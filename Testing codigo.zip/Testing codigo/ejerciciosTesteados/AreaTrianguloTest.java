/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package ejerciciosParaProbar;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author User
 */
public class AreaTrianguloTest {
    
    @Test
    public void testArea() {
        System.out.println("Área de triangulo");
        int base = 4;
        int altura = 7;
        AreaTriangulo instance = new AreaTriangulo();
        int expResult = 14;
        int result = instance.area(base, altura);
        assertEquals(expResult, result);
    }
    @Test
    public void testArea2() {
        System.out.println("Área de triangulo");
        int base = 10;
        int altura = 15;
        AreaTriangulo instance = new AreaTriangulo();
        int expResult = 75;
        int result = instance.area(base, altura);
        assertEquals(expResult, result);    
    }
    @Test
    public void testArea3() {
        System.out.println("Área de triangulo");
        int base = 6;
        int altura = 8;
        AreaTriangulo instance = new AreaTriangulo();
        int expResult = 24;
        int result = instance.area(base, altura);
        assertEquals(expResult, result);    
    } 
}