/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package ejerciciosParaProbar;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author User
 */
public class AreaCuadradoTest {
    
    /**
     * Test of area method, of class AreaCuadrado.
     */
    @Test
    public void testArea() {
        System.out.println("Área del cuadrado");
        int lado1 = 4;
        int lado2 = 5;
        AreaCuadrado instance = new AreaCuadrado();
        int expResult = 20;
        int result = instance.area(lado1, lado2);
        assertEquals(expResult, result);
    }
    @Test
    public void testArea2() {
        System.out.println("Área del cuadrado");
        int lado1 = 5;
        int lado2 = 8;
        AreaCuadrado instance = new AreaCuadrado();
        int expResult = 40;
        int result = instance.area(lado1, lado2);
        assertEquals(expResult, result);
    }
    @Test
    public void testArea3() {
        System.out.println("Área del cuadrado");
        int lado1 = 7;
        int lado2 = 10;
        AreaCuadrado instance = new AreaCuadrado();
        int expResult = 70;
        int result = instance.area(lado1, lado2);
        assertEquals(expResult, result);
    }
}
