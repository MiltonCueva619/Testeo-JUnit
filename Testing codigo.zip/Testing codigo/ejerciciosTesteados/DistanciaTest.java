package ejerciciosParaProbar;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class DistanciaTest {
    
    @Test
    public void prueba1() {
        System.out.println("Distancia");
        int velocidad = 50;
        int tiempo = 2;
        Distancia instance = new Distancia();
        int exprResult = 100;  
        int result = instance.distancia(velocidad, tiempo);
        assertEquals(exprResult, result);  
    }
    
    @Test
    public void prueba2() {
        System.out.println("Distancia");
        int velocidad = 75;
        int tiempo = 3;
        Distancia instance = new Distancia();
        int exprResult = 225;
        int result = instance.distancia(velocidad, tiempo);
        assertEquals(exprResult, result);  
    }  
    
    @Test
    public void prueba3() {
        System.out.println("Distancia");
        int velocidad = 100;
        int tiempo = 4;
        Distancia instance = new Distancia();
        int exprResult = 400;
        int result = instance.distancia(velocidad, tiempo);
        assertEquals(exprResult, result);  
    }  
   
}

